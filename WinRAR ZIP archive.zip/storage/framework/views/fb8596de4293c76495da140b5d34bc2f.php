

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/admin/index.blade.php ENDPATH**/ ?>