

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner-nav','data' => ['title' => 'Request form','navigations' => $navigations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Request form','navigations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navigations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="feedback">
        <div class="container">
            <form class="feedback__form form-contact" enctype="multipart/form-data" action="<?php echo e(route('feedback.send')); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-contact__flex">
                    <label class="label">
                        <span class="label__title">Name</span>
                        <input class="input" name="name" type="text" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label class="label">
                        <span class="label__title">Email</span>
                        <input class="input" name="email" type="email" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                </div>
                <div class="form-contact__flex">
                    <label class="label">
                        <span class="label__title">Question</span>
                        <select class="input" name="question">
                            <option value="" selected>- None -</option>
                            <option value="Order project">Order project</option>
                            <option value="Get answer">Get answer</option>
                        </select>
                    </label>
                    <label class="label">
                        <span class="label__title">Service</span>
                        <select class="input" name="service">
                            <option value="" selected>- None -</option>
                            <option value="Interior">Interior</option>
                            <option value="Exterior">Exterior</option>
                            <option value="Product rendering">Product rendering</option>
                            <option value="Modelling">Modelling</option>
                            <option value="Animation">Animation</option>
                        </select>
                    </label>
                </div>
                <label class="label">
                    <span class="label__title">Message</span>
                    <textarea class="input" name="message" rows="5" required></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <br>
                <label class="label">
                    <span class="label__title">Select file</span>
                    <input class="input" type="file" name="file">
                </label>
                <button class="btn form-contact__btn">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/client/feedback.blade.php ENDPATH**/ ?>