

<?php $__env->startSection('content'); ?>
    <div class="admin-form-editor">
        <h1 class="admin-form-editor__title">Редактирование типа услуги #<?php echo e($service_item->id); ?></h1>
        <form class="admin-form-editor__form" action="<?php echo e(url()->current()); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <label class="label">
                <span class="label__title">Название</span>
                <input class="input" type="text" name="title" value="<?php echo e($service_item->title ?? old('title')); ?>"
                    required />
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="label">
                <span class="label__title">Описание</span>
                <textarea class="input" name="description"><?php echo e($service_item->description ?? old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="label">
                <span class="label__title">Фото</span>
                <input class="input" type="file" name="image" value="<?php echo e(old('image')); ?>" />
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <?php if($service_item->image?->path): ?>
                <img class="admin-form-editor__img" src="<?php echo e(Storage::url($service_item->image->path)); ?>" alt="">
            <?php endif; ?>
            <button class="btn admin-form-editor__btn">Изменить</button>
        </form>
    </div>
    <br>
    <div class="admin-items">
        <div class="admin-items__top">
            <h2>Цены и описание</h2>
            <a class="btn" href="/admin/service-price/create/<?php echo e($service_item->id); ?>">+ Создать</a>
        </div>
        <div class="admin-items-prices__list">
            <div class="admin-items-prices__titles">
                <div class="admin-items-prices__title">Описание</div>
                <div class="admin-items-prices__title">Цена</div>
                <div class="admin-items-prices__title">Цена от?</div>
            </div>
            <?php $__currentLoopData = $service_item->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="admin-items-prices__item" href="/admin/service-price/edit/<?php echo e($service->id); ?>">
                    <div class="admin-items-prices__value"><?php echo e($service->description); ?></div>
                    <div class="admin-items-prices__value"><?php echo e($service->price); ?></div>
                    <div class="admin-items-prices__value"><?php echo e($service->is_from ? 'да' : 'нет'); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/admin/service_item.blade.php ENDPATH**/ ?>