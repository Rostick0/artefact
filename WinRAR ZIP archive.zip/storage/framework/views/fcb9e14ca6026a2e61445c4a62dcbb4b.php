<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss']); ?>
    <title><?php echo $__env->yieldContent('seo_title', 'Title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('seo_description', 'Description'); ?>">
</head>

<body>
    <div class="wrapper">
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/layout/head.blade.php ENDPATH**/ ?>