<?php if($paginator->hasPages() && $paginator->count()): ?>
    <div class="pagination">
        <?php if($paginator->currentPage() != 1): ?>
            <a class="pagination__link" href="<?php echo e($paginator->url(1)); ?>">1</a>
        <?php endif; ?>
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="pagination__link _active"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <?php if($page != 1 && $page != $paginator->lastPage()): ?>
                            <a class="pagination__link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($paginator->currentPage() != $paginator->lastPage()): ?>
            <a class="pagination__link"
                href="<?php echo e($paginator->url($paginator->lastPage())); ?>"><?php echo e($paginator->lastPage()); ?></a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/vendor/pagination.blade.php ENDPATH**/ ?>