<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="auth">
    <div class="auth__inner">
        <h1 class="auth__title">Авторизация</h1>
        <form class="auth__form" action="<?php echo e(url()->current()); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="auth__inputs">
                <label class="label">
                    <span class="label__title">E-mail</span>
                    <input class="input" type="email" name="email" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="label">
                    <span class="label__title">Password</span>
                    <input class="input" type="password" name="password" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>
            <button class="btn auth__btn">Sign up</button>
        </form>
    </div>
</section>

<?php echo $__env->make('layout.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/admin/login.blade.php ENDPATH**/ ?>