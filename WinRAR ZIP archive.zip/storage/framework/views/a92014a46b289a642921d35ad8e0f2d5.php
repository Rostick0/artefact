

<?php $__env->startSection('content'); ?>
    <form class="admin-filter" action="<?php echo e(url()->current()); ?>">
        <div class="admin-filter__inputs">
            <label class="label admin-filter__label">
                <span class="label__title">Название</span>
                <input class="input" type="text" name="title" placeholder="Название" value="<?php echo e(Request::get('title')); ?>">
            </label>
            <label class="label admin-filter__label">
                <span class="label__title">Категория</span>
                <select class="input" name="category_id">
                    <option <?php if(Request::get('category_id') == ''): ?> selected <?php endif; ?> value="">Все</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if(Request::get('category_id') == $item->id): ?> selected <?php endif; ?>>
                            <?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
        </div>
        <button class="btn admin-filter__btn">Поиск</button>
    </form>
    <a class="btn" href="/admin/portfolio/create">+ Создать</a>
    <div class="admin-items">
        <div class="admin-items__list">
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="admin-item" href="/admin/portfolio/edit/<?php echo e($portfolio->id); ?>">
                    <div class="admin-item__title"><?php echo e($portfolio->title); ?></div>
                    <div class="admin-item__image">
                        <img class="admin-item__img" src="<?php echo e(Storage::url($portfolio->image->path)); ?>" alt="">
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php echo e($portfolios->appends(Request::all())->links('vendor.pagination')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/admin/portfolios.blade.php ENDPATH**/ ?>