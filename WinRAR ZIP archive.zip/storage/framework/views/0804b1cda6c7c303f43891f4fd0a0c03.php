

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner-nav','data' => ['title' => $portfolio->title,'navigations' => $navigations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($portfolio->title),'navigations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navigations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <section class="portfolio-one">
        <div class="container">
            <img class="portfolio-one__img" decoding="async" loading="lazy" src="<?php echo e(Storage::url($portfolio->image->path)); ?>" alt="<?php echo e($portfolio->title); ?>" />
            <div class="portfolio-one__info">
                <div class="portfolio-one__category"><?php echo e($portfolio->category->name); ?></div>
                <div class="portfolio-one__date"><?php echo e(\Carbon\Carbon::parse($portfolio->created_at)->format('F d, Y')); ?></div>
            </div>
            <h1 class="portfolio-one__title"><?php echo e($portfolio->title); ?></h1>
            <?php if($portfolio->description): ?>
                <div class="portfolio-one__description"><?php echo $portfolio->description; ?></div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/client/portfolio.blade.php ENDPATH**/ ?>