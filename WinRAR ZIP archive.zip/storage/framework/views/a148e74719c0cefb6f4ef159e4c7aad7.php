</div>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</body>

</html>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/layout/foot.blade.php ENDPATH**/ ?>