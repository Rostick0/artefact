<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['navigations', 'title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['navigations', 'title']); ?>
<?php foreach (array_filter((['navigations', 'title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="banner-nav">
    <div class="container">
        <div class="banner-nav__container">
            <nav class="banner-nav__nav">
                <?php $__currentLoopData = $navigations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($item['is_active'])): ?>
                        <span class="banner-nav__nav_item _active"><?php echo e($item['name']); ?></span>
                    <?php else: ?>
                        <a class="banner-nav__nav_item" href="<?php echo e($item['link']); ?>"><?php echo e($item['name']); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
            <div class="title-banner banner-nav__title"><?php echo e($title); ?></div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/components/banner-nav.blade.php ENDPATH**/ ?>