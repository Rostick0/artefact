

<?php $__env->startSection('content'); ?>
    <form class="admin-filter" action="<?php echo e(url()->current()); ?>">
        <div class="admin-filter__inputs">
            <label class="label admin-filter__label">
                <span class="label__title">Название</span>
                <input class="input" type="text" name="title" placeholder="Название" value="<?php echo e(Request::get('title')); ?>">
            </label>
        </div>
        <button class="btn admin-filter__btn">Поиск</button>
    </form>
    <a class="btn" href="/admin/service/create">+ Создать</a>
    <div class="admin-items">
        <div class="admin-items__list">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="admin-item" href="/admin/service/edit/<?php echo e($service->id); ?>">
                    <div class="admin-item__title"><?php echo e($service->title); ?></div>
                    <div class="admin-item__image">
                        <img class="admin-item__img" src="<?php echo e(Storage::url($service->image->path)); ?>" alt="">
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php echo e($services->appends(Request::all())->links('vendor.pagination')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/admin/services.blade.php ENDPATH**/ ?>