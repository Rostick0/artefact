

<?php $__env->startSection('content'); ?>
    <div class="admin-form-editor">
        <h1 class="admin-form-editor__title">Создание цены и описания</h1>
        <form class="admin-form-editor__form" action="<?php echo e(url()->current()); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <label class="label">
                <span class="label__title">Цена</span>
                <input class="input" type="number" name="price" value="<?php echo e(old('price')); ?>" />
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="label">
                <span class="label__title">Описание</span>
                <input class="input" type="text" name="description" value="<?php echo e(old('description')); ?>" />
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="checkbox">
                <input class="checkbox__input" type="checkbox" name="is_from"
                    <?php if(old('is_from')): ?> checked <?php endif; ?>>
                <span class="checkbox__icon">✓</span>
                <span>Цена от?</span>
            </label>
            <button class="btn admin-form-editor__btn">Изменить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/admin/service_price_create.blade.php ENDPATH**/ ?>