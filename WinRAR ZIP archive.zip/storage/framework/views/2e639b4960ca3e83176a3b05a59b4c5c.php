<?php echo $__env->make('layout.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="admin-main">
    <?php echo $__env->make('layout.admin.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main__content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</main>

<?php echo $__env->make('layout.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/layout/admin/layout.blade.php ENDPATH**/ ?>