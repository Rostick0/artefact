<div class="modal">
    <div class="modal__inner">
        <div class="modal__close">×</div>
        <div class="modal__content">
            <img class="modal__img" decoding="async" loading="lazy" src="" alt="">
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/components/modal.blade.php ENDPATH**/ ?>