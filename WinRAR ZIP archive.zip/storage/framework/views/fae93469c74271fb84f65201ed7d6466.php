

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner-nav','data' => ['title' => 'Panorams','navigations' => $navigations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Panorams','navigations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navigations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <section class="panorams">
        <div class="container">
            <h1 class="title-section panorams__title-section">Panorams</h1>
            <div class="panorams__item panorams-item">
                <div class="panorams-item__title">Heading</div>
                <div class="panorams-item__view">
                    <iframe class="panorams-item__iframe" allowfullscreen="" width="976" height="549" style="border:0;"
                        loading="lazy" referrerpolicy="no-referrer-when-downgrade"
                        src="https://anastasiyaust.github.io/Bedroom-/"></iframe>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/client/panorams.blade.php ENDPATH**/ ?>