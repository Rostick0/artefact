<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['services']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['services']); ?>
<?php foreach (array_filter((['services']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="services-list">
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="services-list__item services-list-item" href="/service/<?php echo e($item->id); ?>">
            <div class="services-list-item__title"><?php echo e($item->title); ?></div>
            <div class="services-list-item__image">
                <img class="services-list-item__img" decoding="async" loading="lazy"
                    src="<?php echo e(Storage::url($item->image->path)); ?>" alt="<?php echo e($item->title); ?>">
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/components/services-list.blade.php ENDPATH**/ ?>