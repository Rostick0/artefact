

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner-nav','data' => ['title' => $service->title,'navigations' => $navigations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service->title),'navigations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($navigations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="service">
        <div class="container">
            <div class="service__date">Submitted by admin on July 25, 2023</div>
            <?php if($service->description): ?>
                <div class="service__description"><?php echo e($service->description); ?></div>
            <?php endif; ?>
            <div class="service__list">
                <?php $__currentLoopData = $service->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service__item service-item">
                        <div class="service-item__image">
                            <div class="service-item__image_inner">
                                <img class="service-item__img" decoding="async" loading="lazy" src="<?php echo e(Storage::url($item->image->path)); ?>"
                                    alt="<?php echo e($item?->title); ?>">
                            </div>
                        </div>
                        <div class="service-item__text">
                            <?php if($item?->title): ?>
                                <div class="service-item__title"><?php echo e($item->title); ?></div>
                            <?php endif; ?>
                            <?php if($item?->description): ?>
                                <div class="service-item__description"><?php echo e($item->description); ?></div>
                            <?php endif; ?>
                            <ul class="service-item__prices">
                                <?php $__currentLoopData = $item?->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="service-item__price"><?php echo e($price?->description); ?> - <?php if($price?->is_from): ?>
                                            from
                                        <?php endif; ?> €<?php echo e($price->price); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="service__description_bottom">
                At our company, we believe in providing transparent and affordable pricing. Our prices are tailored to
                your
                specific needs and requirements, ensuring that you get the best possible value for your money. If you
                have
                any
                questions about our services or pricing, please don't hesitate to get in touch with us. We'd be more
                than
                happy
                to provide you with a quote for your project.
            </div>
            <img class="service__image" decoding="async" loading="lazy" src="<?php echo e(Storage::url($service->image->path)); ?>"
                alt="<?php echo e($service?->title); ?>" />
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/pages/client/service.blade.php ENDPATH**/ ?>