

<?php $__env->startSection('content'); ?>
    <section class="panorams">
        <div class="container">
            <div class="title-section panorams__title-section">Panorams</div>
            <div class="panorams__item">
                <div class="panorams__title">Heading</div>
                <div class="panorams__view">
                    <iframe class="panorams__iframe" allowfullscreen="" width="976" height="549"
                        src="https://anastasiyaust.github.io/Bedroom-/"></iframe>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/panorams.blade.php ENDPATH**/ ?>