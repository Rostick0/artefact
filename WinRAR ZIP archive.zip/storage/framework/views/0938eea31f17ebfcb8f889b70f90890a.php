<aside class="admin-aside">
    <nav class="admin-aside__nav">
        <a class="admin-aside__nav_link<?php echo e(Request::segment(2) === 'service' ? ' _active' : ''); ?>"
            href="/admin/service/list">Услуги</a>
        <a class="admin-aside__nav_link<?php echo e(Request::segment(2) === 'portfolio' ? ' _active' : ''); ?>"
            href="/admin/portfolio/list">Портфолио</a>
    </nav>
</aside>
<?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/layout/admin/aside.blade.php ENDPATH**/ ?>