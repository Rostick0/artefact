<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/scss/admin/index.scss']); ?>

<header class="admin-header">

</header><?php /**PATH C:\Users\Rostislav\OneDrive\Рабочий стол\artefact\resources\views/layout/admin/header.blade.php ENDPATH**/ ?>