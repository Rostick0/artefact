</div>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
@vite(['resources/js/app.js'])
</body>

</html>
