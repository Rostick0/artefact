@include('layout.head')
@vite(['resources/scss/admin/index.scss'])

<header class="admin-header">

</header>