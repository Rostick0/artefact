@include('layout.client.header')

<main class="main">
    @yield('content')
</main>

@include('layout.client.footer')
