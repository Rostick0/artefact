@include('layout.client.header_short')

<main class="main">
    @yield('content')
</main>

@include('layout.client.footer')
