<div class="modal">
    <div class="modal__inner">
        <div class="modal__close">×</div>
        <div class="modal__content">
            <div class="modal__content_inner">
                <img class="modal__img" decoding="async" loading="lazy" src="" alt="">
            </div>
        </div>
    </div>
</div>
